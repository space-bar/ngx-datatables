import {DatatablesTemplateDirective} from "./datatables-template.directive";

describe('DatatablesTemplateDirective', () => {
  it('should create an instance', () => {
    //const directive = new DatatablesTemplateDirective();
    //expect(directive).toBeTruthy();
  });
});
